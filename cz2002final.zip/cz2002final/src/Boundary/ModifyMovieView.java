		package Boundary;

import static Control.DataManager.*;
import static Control.FileManager.*;

import Entity.Movie;
/**
 * 
 * Offers options for modifying information regarding a single movie
 *
 */
public class ModifyMovieView extends View{
	
	private Movie movie;
	
	public ModifyMovieView(Movie movie) {
		this.movie = movie;
	}
	
	public void start() {
		System.out.println("Movie Details\n");
		System.out.println("Title: " + movie.getTitle());
		System.out.println("Age Restriction: " + movie.getAgeRestriction());
		System.out.println("Director: " + movie.getDirector());
		System.out.println("Synopsis: " + movie.getSynopsis());
		System.out.print("Cast: ");
		for (String member: movie.getCast()) System.out.print(member + ", ");
		double rating = getAverageRating(movie);
		if (rating!=0) System.out.println("Rating: " + rating);
		else System.out.println("Rating: No reviews found.");
		System.out.println("Status: " + movie.getStatus());
		System.out.println();
		
		System.out.println("Modify movie\n");
		System.out.println("1. Change movie details.");
		System.out.println("2. Remove movie.");
		System.out.println("3. Add/remove showtime");
		System.out.println("4. Go back.");
		switch (getChoice(1,4)) {
		case 1:
			transit(this, new ChangeMovieDetailsView(movie));
			break;
		case 2:
			movie.setStatus("END OF SHOWING");
			updateMovies(movie);
			System.out.println("\nMovie removed");
			System.out.println("Press ENTER to go back.");
			getString();
			destroy();
			break;
		case 3:
			transit(this, new StaffShowtimeView(movie));
			break;
		default:
			destroy();
		}
	}
}
