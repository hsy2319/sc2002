package Boundary;

import static Control.DataManager.*;
import static Control.FileManager.*;

import java.util.Scanner;

import java.util.ArrayList;

import Entity.Cinema;
import Entity.Movie;

/**
 * 
 * Allows moviegoers to select whether to view movies by search, all movies, or top 5 movies
 *
 */

public class MoviesDisplayView extends View{

	public void start() {
		System.out.println("Movies Display\n");
		System.out.println("Please choose:");
		System.out.println("1. Search movies by title");
		System.out.println("2. See all movies");
		System.out.println("3. See top 5 movies");
		System.out.println("4. Go back\n");
		
		int choice = getChoice(1,4);
		switch (choice) {
		case 1:
			searchMovies();
			break;
		case 2:
			seeAllMovies();
			break;
		case 3:
			seeTop5();
			break;
		case 4:
			destroy();
		}
	}
	
	/**
	 * Returns movies based on user's search term
	 */
	
	private void searchMovies() {
		System.out.println("Enter movie title:");
		String str = getString();
		ArrayList<Movie> foundmovies = getSearchedMovies(str);
		System.out.println(foundmovies.size()+" movies found:");
		for (int i=0;i<foundmovies.size();i++) {
			if (rankByRating()) System.out.println((i+1) + ". " + foundmovies.get(i).getTitle() + " ["+getAverageRating(foundmovies.get(i))+"] ("+foundmovies.get(i).getStatus()+")");
			else System.out.println((i+1) + ". " + foundmovies.get(i).getTitle() + " ["+getSales(foundmovies.get(i))+"] ("+foundmovies.get(i).getStatus()+")");
		}
		System.out.println((foundmovies.size()+1) + ". Go back");
		
		int choice = getChoice(1, foundmovies.size()+1);
		if (choice == foundmovies.size()+1) destroy();
		else printMovieDetails(foundmovies.get(choice-1));
	}
	
	/**
	 * returns movies based on top 5 sales or review ratings
	 */
	
	private void seeTop5() { 
		System.out.println("Please choose how you would like to rank:");
		System.out.println("1. By Sales.");
		System.out.println("2. By Ratings.");
		System.out.println("3. Go Back.");

		int choice = getChoice(1,3);
		switch (choice) {
		case 1://By sales
			switchRanking();
			System.out.println("You choose to rank by "+((rankByRating())?"review rating":"sales"));
	
			break;

		case 2://By ratings
			
			switchRanking();
			System.out.println("You choose to rank by "+((rankByRating())?"review rating":"sales"));
			break;
	
		case 3:
			destroy();
		}
		ArrayList<Movie> movies = getTop5();
		for (int i=0;i<5;i++) {
			if (rankByRating()) System.out.println((i+1) + ". " + movies.get(i).getTitle() + " ["+getAverageRating(movies.get(i))+"] ("+movies.get(i).getStatus()+")");
			else System.out.println((i+1) + ". " + movies.get(i).getTitle() + " ["+getSales(movies.get(i))+"] ("+movies.get(i).getStatus()+")");
		}
		System.out.println("6. Go back");

		
		int newchoice = getChoice(1, movies.size()+1);
		if (newchoice == movies.size()+1) destroy();
		else printMovieDetails(movies.get(newchoice-1));
	}
	
	
	/**
	 * Returns all movies in the file
	 */
	private void seeAllMovies() {
		ArrayList<Movie> movies = getMovies();
		for (int i=0;i<movies.size();i++) {
			if (rankByRating()) System.out.println((i+1) + ". " + movies.get(i).getTitle() + " ["+getAverageRating(movies.get(i))+"] ("+movies.get(i).getStatus()+")");
			else System.out.println((i+1) + ". " + movies.get(i).getTitle() + " ["+getSales(movies.get(i))+"] ("+movies.get(i).getStatus()+")");
		}
		System.out.println((movies.size()+1) + ". Go back");
		
		int choice = getChoice(1, movies.size()+1);
		if (choice == movies.size()+1) destroy();
		else printMovieDetails(movies.get(choice-1));
	}
	
	/**
	 * Prints all the information regarding the movie
	 * @param movie
	 */
	private void printMovieDetails(Movie movie) {
		System.out.println("Movie Details\n");
		System.out.println("Title: " + movie.getTitle());
		System.out.println("Age Restriction: " + movie.getAgeRestriction());
		System.out.println("Director: " + movie.getDirector());
		System.out.println("Synopsis: " + movie.getSynopsis());
		System.out.print("Cast: ");
		for (String member: movie.getCast()) System.out.print(member + ", ");
		double rating = getAverageRating(movie);
		if (rating!=0) System.out.println("Rating: " + rating);
		else System.out.println("Rating: No reviews found.");
		System.out.println("Status: " + movie.getStatus());
		System.out.println();
		System.out.println("1. Display showtime(s).");
		System.out.println("2. Read/ Write review(s).");
		System.out.println("3. Go back.\n");
		
		int choice = getChoice(1,3);
		switch (choice) {
		case 1:
			transit(this, new ShowtimeView(movie));
			break;
		case 2:
			transit(this, new ReviewView(movie));
			break;
		case 3:
			destroy();
		}
	}
}
