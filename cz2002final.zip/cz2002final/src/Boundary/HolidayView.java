package Boundary;

import static Control.DataManager.*;
import static Control.FileManager.*;

import java.util.ArrayList;
import java.util.Date;

import Entity.Holiday;
/**
 * 
 * Allows staff to create and remove holidays
 *
 */
public class HolidayView extends View {

	@Override
	public void start() {
		// TODO Auto-generated method stub
		ArrayList<Holiday> holidays = getHolidays();
		System.out.println("\nModify holidays:\n");
		for (int i=0;i<holidays.size();i++) {
			System.out.println((i+1)+". "+holidays.get(i).getName());
		}
		System.out.println((holidays.size()+1)+". Create new holiday.");
		System.out.println((holidays.size()+2)+". Go back.");
		System.out.println("\nChoose holiday to remove or create new holiday:");
		int choice = getChoice(1,holidays.size()+2);
		if (choice==holidays.size()+2) {
			destroy();
		}
		else if (choice==holidays.size()+1) {
			System.out.println("Holiday name:");
			String name = getString();
			System.out.println("Please enter the holiday date in dd-MM-yyyy hh:mm form (eg. 21-04-2023 12:00): ");
			Date time = getDate();
			System.out.println("Holiday price rate (e.g. 0.7: 70% normal price):");
			Double rate = getDouble();
			holidays.add(new Holiday(name, time, rate));
			updateHolidays(holidays);
		}
		else {
			holidays.remove(choice-1);
			updateHolidays(holidays);
		}
		System.out.println("Holiday created");
		System.out.println("Press ENTER to go back.");
		getString();
		destroy();
	}

}
