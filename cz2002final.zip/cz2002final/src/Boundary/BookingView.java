package Boundary;

import Entity.BookingHistory;
import Entity.Moviegoer;
import Entity.Showtime;
import static Control.DataManager.*;
import static Control.FileManager.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
/**
 * 
 * UI for moviegoers to book tickets
 *
 */
public class BookingView extends View{
	
	Showtime showtime;
	/**
	 * 
	 * @param showtime the showtime object used to print seats and calculate pricing
	 */
	public BookingView(Showtime showtime) {
		this.showtime = showtime;
	}
	
	public void start() {
		printSeats(showtime);
		System.out.println();
		int rowcolumn = checkSeat(showtime);
		System.out.println("\nBooking:\n");
		printPricing(showtime, true, true);
		System.out.print("\nYour name:");
		String name = getString();
		System.out.print("Your mobile:");
		String mobile = getString();
		System.out.print("Your email:");
		String email = getString();
		System.out.print("Are you a senior citizen? (y/n):");
		boolean isSenior = getYesNo();
		
		System.out.println("\n1. Confirm booking and payment.");
		System.out.println("2. Cancel booking.");
		
		int choice = getChoice(1,2);
		switch (choice) {
		case 1:
			String TID = showtime.getCinema().getCode()+new SimpleDateFormat("yyyyMMddhhmm").format(new Date());
			BookingHistory bookingHistory = new BookingHistory(TID, new Moviegoer(name,mobile,email,isSenior), rowcolumn, showtime);
			showtime.getSeats()[(rowcolumn-10000)/100-1][rowcolumn%100-1] = 1;
			updateShowtime(showtime);
			printTicket(bookingHistory);
			break;
		case 2:
			destroy();
		}
	}
	/**
	 *  prints the ticket for moviegoers after booking
	 * @param booking contains information needed to print the ticket
	 */
	private void printTicket(BookingHistory booking) {
		System.out.println("Ticket Display: \n");
		
		addBookingHistory(booking);
		
		System.out.println("TID: "+booking.getTID());
		double price = printPricing(booking.getShowtime(), !booking.getMoviegoer().getIsSeniorCitizen(), booking.getMoviegoer().getIsSeniorCitizen());
		System.out.println("Booking fee: $2");
		System.out.println("GST: $" + (double) Math.round(100*price*0.07)/100);
		System.out.println("Total price: $" + (double) Math.round(100*(price*1.07+2))/100);
		if (booking.getMoviegoer().getIsSeniorCitizen()) System.out.println("(50% off for senior citizens.)");
		
		System.out.println("\nPress ENTER to go back.");
		getString();
		destroy();
	}
}
