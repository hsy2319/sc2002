package Boundary;

import static Control.DataManager.*;
import static Control.FileManager.*;

import java.util.ArrayList;

import Entity.Movie;

/**
 * 
 * Displays all movies to be used in modifying the movies
 *
 */

public class StaffMovieDisplayView extends View{
	
	public void start() {
		ArrayList<Movie> movies = getMovies();
		for (int i=0;i<movies.size();i++) {
			if (rankByRating()) System.out.println((i+1) + ". " + movies.get(i).getTitle() + " ["+getAverageRating(movies.get(i))+"] ("+movies.get(i).getStatus()+")");
			else System.out.println((i+1) + ". " + movies.get(i).getTitle() + " ["+getSales(movies.get(i))+"]("+movies.get(i).getStatus()+")");
		}
		System.out.println((movies.size()+1) + ". Add movie.");
		System.out.println((movies.size()+2) + ". Go back");
		
		int choice = getChoice(1, movies.size()+2);
		if (choice == movies.size()+1) transit(this, new addMovieView());
		else if (choice == movies.size()+2) destroy();
		else transit(this, new ModifyMovieView(movies.get(choice-1)));
	}
	
}
