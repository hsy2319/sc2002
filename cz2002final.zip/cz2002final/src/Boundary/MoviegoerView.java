package Boundary;

import static Control.DataManager.*;

/**
 * 
 * Launches the UI for moviegoers
 *
 */

public class MoviegoerView extends View{
	public void start() {
		System.out.println("Moviegoer\n");
		System.out.println("Please choose:");
		System.out.println("1. Search or list movies");
		System.out.println("2. View booking history");
		System.out.println("3. Exit application\n");
		
		int choice = getChoice(1,3);
		switch (choice) {
		case 1:
			transit(this, new MoviesDisplayView());
			break;
		case 2:
			transit(this, new BookingHistoryView());
			break;
		case 3:
			System.out.println("Application exited");
			System.exit(0);
		}
	}
}
