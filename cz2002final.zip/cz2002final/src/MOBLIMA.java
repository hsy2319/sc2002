
import static Control.DataManager.*;
import Boundary.*;
import static Control.FileManager.*;

/**
 * 
 * Launcher for the application
 *
 */

public class MOBLIMA extends View {
	/**
	 * verifies that all files are present. if not, quits the application
	 */
	public void start() {
		if (!readAllFiles()) {
			System.out.println("Data files not found");
			destroy();
		}
		else {
			System.out.println("Movie Booking and Listing Management Application\n");
			System.out.println("Please choose moviegoer or staff.");
			System.out.println("1. Moviegoer");
			System.out.println("2. Staff");
			System.out.println("3. Exit application\n");
			
			int choice = getChoice(1,3);
			switch (choice) {
			case 1:
				transit(this, new MoviegoerView());
				break;
			case 2:
				transit(this, new staffView());
				break;
			case 3:
				destroy();
			}
		}
	}
	
	public static void main(String[] args) {
		new MOBLIMA().start();

	}

}
