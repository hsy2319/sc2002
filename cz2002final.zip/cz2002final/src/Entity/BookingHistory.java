package Entity;

/**
 * 
 * Entity class representing booking history
 *
 */
public class BookingHistory {
	
	private String TID;
	private Moviegoer moviegoer;
	private int seat;
	private Showtime showtime;
	
	public BookingHistory(String TID, Moviegoer moviegoer, int seat, Showtime showtime) {
		this.TID = TID;
		this.moviegoer = moviegoer;
		this.seat = seat;
		this.showtime = showtime;
	}
	
	public String getTID() {
		return TID;
	}
	
	public Moviegoer getMoviegoer() {
		return moviegoer;
	}
	
	public int getSeat() {
		return seat;
	}
	
	public Showtime getShowtime() {
		return showtime;
	}
}
