package Entity;

import java.util.Date;

public class Showtime {
	
	private Movie movie;
    private Cinema cinema;
    private Date time;
    public static final int ROWS = 8;
    public static final int COLUMNS = 16;
    private int[][] seats = new int[ROWS][COLUMNS];
    
    public Showtime(Movie movie, Cinema cinema, Date time, int[][] seats) {
    	this.movie = movie;
    	this.cinema = cinema;
    	this.time = time;
    	this.seats = seats;
    }
    
    public Movie getMovie() {
    	return movie;
    }
    
    public Cinema getCinema() {
    	return cinema;
    }
    
    public Date getTime() {
    	return time;
    }
    
    public int[][] getSeats(){
    	return seats;
    }
}