package Entity;

import java.util.ArrayList;

/**
 * 
 * Entity class representing a movie
 *
 */

public class Movie {
    private String title;
    private String ageRestriction;
    private String director;
    private String synopsis;
    private ArrayList<String> cast;
    private String status;

    public Movie(String title, String ageRestriction, String director, String synopsis, ArrayList<String> cast, String status) {
        this.title = title;
        this.ageRestriction = ageRestriction;
        this.director = director;
        this.synopsis = synopsis;
        this.cast = cast;
        this.status = status;
    }
    
    public String getTitle() {
    	return title;
    }
    
    public String getAgeRestriction() {
    	return ageRestriction;
    }
    
    public void setAgeRestriction(String ageRestriction) {
    	this.ageRestriction = ageRestriction;
    }
    
    public String getDirector() {
    	return director;
    }
    
    public void setDirector(String director) {
    	this.director = director;
    }
    
    public String getSynopsis() {
    	return synopsis;
    }
    
    public void setSynopsis(String synopsis) {
    	this.synopsis = synopsis;
    }
    
    public ArrayList<String> getCast() {
    	return cast;
    }
    
    public void setCast(ArrayList<String> cast) {
    	this.cast = cast;
    }
    
    public String getStatus() {
    	return status;
    }
    
    public void setStatus(String status) {
    	this.status = status;
    }
}