package Control;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import Entity.*;
/**
 * 
 * Reads and writes data to csv files
 *
 */
public class FileManager {
	private static final String BOOKINGHISTORY_FILE = "data/bookingHistory.csv";
	private static final String MOVIE_FILE = "data/movies.csv";
	private static final String CINEMA_FILE = "data/cinemas.csv";
	private static final String HOLIDAY_FILE = "data/holidays.csv";
	private static final String REVIEW_FILE = "data/reviews.csv";
	private static final String SHOWTIME_FILE = "data/showtimes.csv";
	private static final String SYSTEM_FILE = "data/system.csv";
	
	private static ArrayList<BookingHistory> bookingHistoryList = new ArrayList<BookingHistory>();
	private static ArrayList<Movie> movies = new ArrayList<Movie>();
	private static ArrayList<Cinema> cinemas = new ArrayList<Cinema>();
	private static ArrayList<Holiday> holidays = new ArrayList<Holiday>();
	private static ArrayList<Review> reviews = new ArrayList<Review>();
	private static ArrayList<Showtime> showtimes = new ArrayList<Showtime>();
	private static String staffUsername, staffPassword;
	private static boolean rankByRating;
	public static double weekendPremium, is3dPremium, isPlatinumPremium;
	
	public static boolean readAllFiles() {
		try {
			readMovies();
			readCinemas();
			readShowtimes();
			readBookingHistory();
			readHolidays();
			readReviews();
			readSettings();
			return true;
		} catch (IOException e) {
			return false;
		}
	}

	private static void readMovies() throws IOException{
		BufferedReader in = new BufferedReader(new FileReader(MOVIE_FILE));
        String line;
        while ((line = in.readLine()) != null) {
        	String title = line.split(";")[0];
        	String ageRestriction = line.split(";")[1];
        	String director = line.split(";")[2];
        	String synopsis = line.split(";")[3];
        	String castlist = line.split(";")[4];
        	ArrayList<String> cast = new ArrayList<String>();
        	for (String s: castlist.split(":")) {cast.add(s);}
        	String status = line.split(";")[5];
        	movies.add(new Movie(title, ageRestriction, director, synopsis, cast, status));
        }
        in.close();
	}
	
	private static void readCinemas() throws IOException{
		BufferedReader in = new BufferedReader(new FileReader(CINEMA_FILE));
        String line;
        while ((line = in.readLine()) != null) {
        	String cineplex = line.split(";")[0];
        	boolean isPlatinum = Boolean.parseBoolean(line.split(";")[1]);
        	boolean is3d = Boolean.parseBoolean(line.split(";")[2]);
        	String code = line.split(";")[3];
        	double basePrice = Double.parseDouble(line.split(";")[4]);
        	cinemas.add(new Cinema(cineplex, isPlatinum, is3d, code, basePrice));
        }
        in.close();
	}
	
	private static void readShowtimes() throws IOException{
		//Movie movie, Cinema cinema, Date time, int[][] seats
		BufferedReader in = new BufferedReader(new FileReader(SHOWTIME_FILE));
        String line;
        while ((line = in.readLine()) != null) {
        	String moviestr = line.split(";")[0];
        	Movie thismovie = null;
        	for (Movie movie: movies) {
        		if (movie.getTitle().equals(moviestr)) {
        			thismovie = movie;
        			break;
        		}
        	}
        	String cinemastr = line.split(";")[1];
        	Cinema thiscinema = null;
        	for (Cinema cinema: cinemas) {
        		if (cinema.getCode().equals(cinemastr)) {
        			thiscinema = cinema;
        			break;
        		}
        	}
        	String datestr = line.split(";")[2];
        	Date time = new Date();
            try {
				time=new SimpleDateFormat("yyyyMMddhhmm").parse(datestr);
			} catch (ParseException e) {
				e.printStackTrace();
			}
            int[][] seats = new int[Showtime.ROWS][Showtime.COLUMNS];
            for (int i=0;i<Showtime.ROWS;i++) {
            	for (int j=0;j<Showtime.COLUMNS;j++) {
            		seats[i][j] = 0;
            	}
            }
            try {
	            String seatstr[] = line.split(";")[3].split(":");
	            for (String str: seatstr) {
	            	int row = Integer.parseInt(str.substring(1,3));
	            	int column = Integer.parseInt(str.substring(3));
	            	seats[row-1][column-1] = 1;
	            }
            } catch (ArrayIndexOutOfBoundsException e) {
            	
            }
            showtimes.add(new Showtime(thismovie, thiscinema, time, seats));
        }
        in.close();
	}
	
	private static void readBookingHistory() throws IOException{
		BufferedReader in = new BufferedReader(new FileReader(BOOKINGHISTORY_FILE));
        String line;
        while ((line = in.readLine()) != null) {
        	String TID = line.split(";")[0];
        	String name = line.split(";")[1];
        	String mobile = line.split(";")[2];
        	String email = line.split(";")[3];
        	boolean isSeniorCitizen = Boolean.parseBoolean(line.split(";")[4]);
        	Moviegoer moviegoer = new Moviegoer(name, mobile, email, isSeniorCitizen);
        	int seat = Integer.parseInt(line.split(";")[5]);
        	String showtimeID = line.split(";")[6];
        	Showtime showtime = null;
        	for (Showtime st: showtimes) {
        		String ID = st.getCinema().getCode() + new SimpleDateFormat("yyyyMMddhhmm").format(st.getTime());
        		if (ID.equals(showtimeID)) {
        			showtime = st;
        			break;
        		}
        	}
        	if (showtime!=null) bookingHistoryList.add(new BookingHistory(TID, moviegoer, seat, showtime));
        }
        in.close();
	}
	
	private static void readHolidays() throws IOException{
		BufferedReader in = new BufferedReader(new FileReader(HOLIDAY_FILE));
        String line;
        while ((line = in.readLine()) != null) {
        	String name = line.split(";")[0];
        	String datestr = line.split(";")[1];
        	Date time = new Date();
            try {
				time=new SimpleDateFormat("MMdd").parse(datestr);
			} catch (ParseException e) {
				e.printStackTrace();
			}
            Double rate = Double.parseDouble(line.split(";")[2]);
        	holidays.add(new Holiday(name, time, rate));
        }
        in.close();
	}
	
	private static void readReviews() throws IOException{
		BufferedReader in = new BufferedReader(new FileReader(REVIEW_FILE));
        String line;
        while ((line = in.readLine()) != null) {
        	String moviestr = line.split(";")[0];
        	Movie thismovie = null;
        	for (Movie movie: movies) {
        		if (movie.getTitle().equals(moviestr)) {
        			thismovie = movie;
        			break;
        		}
        	}
        	int rating = Integer.parseInt(line.split(";")[1]);
        	String content = line.split(";")[2];
        	String name = line.split(";")[3];
        	reviews.add(new Review(thismovie, rating, content, name));
        }
        in.close();
	}
	
	private static void readSettings() throws IOException{
		BufferedReader in = new BufferedReader(new FileReader(SYSTEM_FILE));
		String line = in.readLine();
		staffUsername = line.split(";")[0];
		staffPassword = line.split(";")[1];
		if (line.split(";")[2].equals("rating")) rankByRating = true;
		else rankByRating = false;
		weekendPremium = Double.parseDouble(line.split(";")[3]);
		is3dPremium = Double.parseDouble(line.split(";")[4]);
		isPlatinumPremium = Double.parseDouble(line.split(";")[5]);
	}
	
	public static ArrayList<Movie> getMovies() {
		return movies;
	}
	
	public static ArrayList<Movie> getSearchedMovies(String search) {
		ArrayList<Movie> searched = new ArrayList<Movie>();
		for (Movie movie: getMovies()) {
			if (movie.getTitle().contains(search)) searched.add(movie); 
		}
		return searched;
	}
	
	public static ArrayList<Cinema> getCinemas() {
		return cinemas;
	}
	
	public static ArrayList<Showtime> getShowtimes(Movie movie) {
		ArrayList<Showtime> movieShowtimes = new ArrayList<Showtime>();
		for (Showtime showtime: showtimes) {
			if (showtime.getMovie().getTitle().equals(movie.getTitle())) {
				movieShowtimes.add(showtime);
			}
		}
		return movieShowtimes;
	}
	
	public static ArrayList<BookingHistory> getBookingHistory() {
		return bookingHistoryList;
	}
	
	public static ArrayList<Holiday> getHolidays() {
		return holidays;
	}
	
	public static ArrayList<Review> getMovieReviews(Movie movie) {
		ArrayList<Review> moviereviews = new ArrayList<Review>();
		for (Review review: reviews) {
			if (review.getMovie().getTitle().equals(movie.getTitle())) {
				moviereviews.add(review);
			}
		}
		return moviereviews;
	}
	
	public static void addReview(Review review) {
		try {	
			reviews.add(review);
			BufferedWriter in = new BufferedWriter(new FileWriter(REVIEW_FILE));
			for (Review review_entry: reviews) {
				in.write(review_entry.getMovie().getTitle()+";"+review_entry.getRating()+";"+review_entry.getContent()+";"+review_entry.getName());
				in.newLine();
			}
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void addMovie(Movie movie) {
		try {	
			movies.add(movie);
			BufferedWriter in = new BufferedWriter(new FileWriter(MOVIE_FILE));
			for (Movie movie_entry: movies) {
				String caststr = "";
				for (String member: movie_entry.getCast()) caststr+=(member+":");
				in.write(movie_entry.getTitle()+";"+movie_entry.getAgeRestriction()+";"+movie_entry.getDirector()+";"+movie_entry.getSynopsis()+";"+caststr+";"+movie_entry.getStatus());
				in.newLine();
			}
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void addBookingHistory(BookingHistory hist) {
		try {	
			bookingHistoryList.add(hist);
			BufferedWriter in = new BufferedWriter(new FileWriter(BOOKINGHISTORY_FILE));
			for (BookingHistory bh: bookingHistoryList) {
				in.write(bh.getTID()+";"+bh.getMoviegoer().getName()+";"+bh.getMoviegoer().getMobile()+";"+bh.getMoviegoer().getEmail()+";"+bh.getMoviegoer().getIsSeniorCitizen()+";"+bh.getSeat()+";"+bh.getShowtime().getCinema().getCode()+new SimpleDateFormat("yyyyMMddhhmm").format(bh.getShowtime().getTime()));
				in.newLine();
			}
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static double getAverageRating(Movie movie) {
		ArrayList<Review> moviereviews = getMovieReviews(movie);
		double total = 0;
		for (Review review: moviereviews) total += (double) review.getRating();
		return  Math.round(100*total/moviereviews.size())/100;
	}
	
	public static int getSales(Movie movie) {
		int sales = 0;
		for (BookingHistory booking: bookingHistoryList) if (booking.getShowtime().getMovie().getTitle().equals(movie.getTitle())) sales++;
		return sales;
	}
	
	public static boolean rankByRating() {
		return rankByRating;}
	
	public static ArrayList<Movie> getTop5(){
		ArrayList<Movie> temp = new ArrayList<Movie>();
		ArrayList<Movie> top5=new ArrayList<Movie>();
		for (Movie movie: getMovies()) if (!movie.getStatus().equals("COMING SOON")) temp.add(movie);
		if (rankByRating) Collections.sort(temp, (o1, o2) -> Double.compare(getAverageRating(o2), getAverageRating(o1)));
		else Collections.sort(temp, (o1, o2) -> Double.compare(getSales(o2), getSales(o1)));
		for(int i=0;i<5;i++) {
			top5.add(temp.get(i));
		}
		return top5;
	}
	
	public static void updateShowtime(Showtime showtime) {
		for (Showtime showtime_entry: showtimes) {
			if (showtime.getCinema().getCode().equals(showtime_entry.getCinema().getCode()) && new SimpleDateFormat("dd/MM/yyyy hh:mm").format(showtime.getTime()).equals(new SimpleDateFormat("dd/MM/yyyy hh:mm").format(showtime_entry.getTime())))
				showtime_entry = showtime;
		}
		try {
			BufferedWriter in = new BufferedWriter(new FileWriter(SHOWTIME_FILE));
			for (Showtime showtime_entry: showtimes) {
				String seats = "";
				for (int i=0;i<8;i++) {
					for (int j=0;j<16;j++) {
						if (showtime_entry.getSeats()[i][j]==1) seats+=(Integer.toString(10000+(i+1)*100+j+1)+":");
					}
				}
				in.write(showtime_entry.getMovie().getTitle()+";"+showtime_entry.getCinema().getCode()+";"+new SimpleDateFormat("yyyyMMddhhmm").format(showtime_entry.getTime())+";"+seats);
				in.newLine();
			}
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static boolean checkStaffLogin(String username, String password) {
		if (username.equals(staffUsername) && password.equals(staffPassword)) return true;
		else return false;
		}

	public static void updateMovies(Movie movie) {
		for (Movie movie_entry: movies) {
			if (movie.getTitle().equals(movie_entry.getTitle())) movie_entry = movie;
		}
		try {
			BufferedWriter in = new BufferedWriter(new FileWriter(MOVIE_FILE));
			for (Movie movie_entry: movies) {
				String caststr = "";
				for (String member: movie_entry.getCast()) caststr+=(member+":");
				in.write(movie_entry.getTitle()+";"+movie_entry.getAgeRestriction()+";"+movie_entry.getDirector()+";"+movie_entry.getSynopsis()+";"+caststr+";"+movie_entry.getStatus());
				in.newLine();
			}
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void removeShowtime(Showtime showtime){
		showtimes.remove(showtime);
		try {
				BufferedWriter in = new BufferedWriter(new FileWriter(SHOWTIME_FILE));
				for (Showtime showtime_entry: showtimes) {
					String seats = "";
					for (int i=0;i<8;i++) {
						for (int j=0;j<16;j++) {
							if (showtime_entry.getSeats()[i][j]==1) seats+=(Integer.toString(10000+(i+1)*100+j+1)+":");
						}
					}
					in.write(showtime_entry.getMovie().getTitle()+";"+showtime_entry.getCinema().getCode()+";"+new SimpleDateFormat("yyyyMMddhhmm").format(showtime_entry.getTime())+";"+seats);
					in.newLine();
				}
				in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	public static void addShowTime(Showtime showtime) {
		showtimes.add(showtime);
		try {
			BufferedWriter in = new BufferedWriter(new FileWriter(SHOWTIME_FILE));
			for (Showtime showtime_entry: showtimes) {
				String seats = "";
				for (int i=0;i<8;i++) {
					for (int j=0;j<16;j++) {
						if (showtime_entry.getSeats()[i][j]==1) seats+=(Integer.toString(10000+(i+1)*100+j+1)+":");
					}
				}
				in.write(showtime_entry.getMovie().getTitle()+";"+showtime_entry.getCinema().getCode()+";"+new SimpleDateFormat("yyyyMMddhhmm").format(showtime_entry.getTime())+";"+seats);
				in.newLine();
			}
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void switchRanking() {
		if (rankByRating) rankByRating = false;
		else rankByRating = true;
		try {
			BufferedReader in = new BufferedReader(new FileReader(SYSTEM_FILE));
			String line = in.readLine();
			in.close();
			BufferedWriter out = new BufferedWriter(new FileWriter(SYSTEM_FILE));
			if (rankByRating) out.write(line.replace("sales", "rating"));
			else out.write(line.replace("rating", "sales"));
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void updateCinemas(ArrayList<Cinema> thiscinemas) {
		cinemas = thiscinemas;
		try {
			BufferedWriter in = new BufferedWriter(new FileWriter(CINEMA_FILE));
			for (Cinema cinema: thiscinemas) {
				in.write(cinema.getCineplex()+";"+cinema.getIsPlatinum()+";"+cinema.getIs3d()+";"+cinema.getCode()+";"+cinema.getBasePrice());
				in.newLine();
			}
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void updateHolidays(ArrayList<Holiday> holiday) {
		holidays = holiday;
		try {
			BufferedWriter in = new BufferedWriter(new FileWriter(HOLIDAY_FILE));
			for (Holiday hld: holidays) {
				in.write(hld.getName()+";"+new SimpleDateFormat("yyyyMMddhhmm").format(hld.getDate())+";"+hld.getRate());
				in.newLine();
			}
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
