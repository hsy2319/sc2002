/**
 * View contains classes of User interface.
 */
package View;