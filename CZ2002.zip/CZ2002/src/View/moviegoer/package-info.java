/**
 * View.staff contains classes of User Interface for moviegoers.
 */
package View.moviegoer;