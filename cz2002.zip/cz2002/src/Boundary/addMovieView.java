package Boundary;

import static Control.DataManager.*;
import static Control.FileManager.*;

import java.util.ArrayList;

import Entity.Movie;
/**
 * 
 * UI for staff to add movies
 *
 */
public class addMovieView extends View{

	public void start() {
		System.out.println("\nAdding movie:\n");
		System.out.print("Title:");
		String title = getString();
		System.out.print("Choose age restriction (1. G, 2. PG, 3. PG13, 4. M18, 5. R21):");
		String ageRestriction;
		switch (getChoice(1,5)) {
		case 1:
			ageRestriction = "G";
			break;
		case 2:
			ageRestriction = "PG";
			break;
		case 3:
			ageRestriction = "PG13";
			break;
		case 4:
			ageRestriction = "M18";
			break;
		default:
			ageRestriction = "R21";
		}
		System.out.print("Director:");
		String director = getString();
		System.out.print("Synopsis:");
		String synopsis = getString();
		System.out.print("Cast (Separate cast members with ':', eg. \"john:mary\" :");
		String caststr = getString();
		ArrayList<String> cast = new ArrayList<String>();
		for (String i: caststr.split(":")) cast.add(i);
		System.out.print("Choose movie showing status (1. COMING SOON, 2. NOW SHOWING, 3. END OF SHOWING) :");
		String status;
		switch (getChoice(1,3)) {
		case 1:
			status = "COMING SOON";
			break;
		case 2:
			status = "NOW SHOWING";
			break;
		default:
			status = "END OF SHOWING";
		}
		addMovie(new Movie(title, ageRestriction, director, synopsis, cast, status));
		System.out.println("Movie added.\n");
		
		System.out.println("Press ENTER to go back.");
		getString();
		destroy();
	}
}
