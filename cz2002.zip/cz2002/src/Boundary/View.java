package Boundary;

/**
 * 
 * superclass that is inherited by all boundary classes. allows user to go from 1 menu to the next
 *
 */
public abstract class View {
	private View preView;
	
	/**
	 * Abstract start method is called when switching to a menu
	 */
	public abstract void start();
	
	/**
	 * called to go back to previous view from current view
	 */
	public void destroy() {
		if (preView==null) {
			System.out.println("Application exited");
			System.exit(0);
		}
		else preView.start();
	}
	
	/**
	 * called to initialize the next view from the current one
	 * @param cur
	 * @param next
	 */
	public void transit(View cur, View next) {
		next.preView = cur;
		next.start();
	}
	
	/**
	 * contains the previous view used by the current view
	 * @return
	 */
	public View getPreView() {
		return preView;
	}
}
