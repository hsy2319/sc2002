package Boundary;

import static Control.DataManager.*;
import static Control.FileManager.*;

import java.util.ArrayList;

import Entity.Cinema;
/**
 * 
 * Class for choosing modifications for staff settings 
 *
 */
public class StaffSettingsView extends View{

	public void start() {
		System.out.println("Staff Settings\n");
		System.out.println("Please choose:");
		System.out.println("1. Change ticket price of cinemas.");
		System.out.println("2. Change top 5 movies ranking option (rating/ sales).");
		System.out.println("3. Modify holidays.");
		System.out.println("4. Go back.");
		
		int choice = getChoice(1,5);
		switch (choice) {
		case 1:
			System.out.println("Choose cinema:");
			ArrayList<Cinema> cinemas = getCinemas();
			for (int i=0; i<cinemas.size();i++) {
				System.out.println((i+1)+". Cineplex:"+cinemas.get(i).getCineplex()+" Cinema code: "+cinemas.get(i).getCode());
				
			}
			Cinema thiscinema = cinemas.get(getChoice(1,cinemas.size())-1);
			System.out.println("Current base price: $"+ thiscinema.getBasePrice());
			System.out.print("Enter new price: ");
			thiscinema.setBasePrice(getDouble());
			updateCinemas(cinemas);
			System.out.println("Cinema price changed.");
			System.out.println("Press ENTER to go back.");
			getString();
			destroy();
			break;
		case 2:
			switchRanking();
			System.out.println("Ranking system now changed to "+((rankByRating())?"review rating":"sales"));
			destroy();
			break;
		case 3:
			transit(this, new HolidayView());
			break;
		case 4:
			destroy();
		}
	}
	
}
