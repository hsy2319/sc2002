package Boundary;

import static Control.DataManager.*;
import static Control.FileManager.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import Entity.Movie;
import Entity.Review;

/**
 * 
 * Allows users to see and write reviews
 *
 */

public class ReviewView extends View{
	
	private Movie movie;
	
	public ReviewView(Movie movie) {
		this.movie = movie;
	}
	
	public void start() {
		System.out.println("Reviews:\n");
		System.out.println("1. See reviews.");
		System.out.println("2. Write reviews.");
		System.out.println("3. Go back.\n");
		
		int choice = getChoice(1,3);
		switch (choice) {
		case 1:
			seeReviews();
			break;
		case 2:
			writeReviews();
			break;
		case 3:
			destroy();
		}
	}
	
	private void seeReviews() {
		for (Review review: getMovieReviews(movie)) {
			System.out.print("Name:" + review.getName());
			System.out.println("     Date:" + new SimpleDateFormat("dd/MM/yyyy").format(review.getDate()));
			System.out.println("Rating: " + review.getRating());
			System.out.println("Review: " + review.getContent());
			System.out.println();
		}
		
		System.out.println("Press ENTER to go back.");
		getString();
		destroy();
	}
	
	private void writeReviews() {
		System.out.println("Your name:");
		String name = getString();
		System.out.println("Your rating:");
		int rating = getInt();
		System.out.println("Your review:");
		String content = getString();
		addReview(new Review(movie, rating, content, name));
		System.out.println("Review added.");
		System.out.println("Press ENTER to go back.");
		getString();
		destroy();
	}
}
