package Boundary;

import static Control.DataManager.*;
import static Control.FileManager.*;
/**
 * 
 * Main boundary class for staff, allows login
 *
 */
public class staffView extends View{
	private boolean isLoggedIn;
	
	public staffView() {
		isLoggedIn = false;
	}
	
	public void start() {
		if (!isLoggedIn) {
			System.out.println("Login\n");
			System.out.print("Username:");
			String username = getString();
			System.out.print("Password:");
			String password = getString();
			if (!checkStaffLogin(username, password)) {
				destroy();
			}
			else {
				isLoggedIn = true;
			}
		}
		System.out.println("Staff\n");
		System.out.println("Please choose:");
		System.out.println("1. Modify movies");
		System.out.println("2. Modify system settings");
		System.out.println("3. Exit application\n");
		
		int choice = getChoice(1,3);
		switch (choice) {
		case 1:
			transit(this, new StaffMovieDisplayView());
			break;
		case 2:
			transit(this, new StaffSettingsView());
			break;
		case 3:
			System.out.println("Application exited");
			System.exit(0);
		}
	}
}
