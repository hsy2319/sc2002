package Boundary;

import static Control.DataManager.*;
import static Control.FileManager.*;

import java.text.SimpleDateFormat;

import Entity.BookingHistory;

/**
 * 
 * UI for moviegoers to look at booking history
 *
 */
public class BookingHistoryView extends View{
	public void start() {
		System.out.println("Booking History\n");
		
		for (BookingHistory bookinghistory: getBookingHistory()) {
			System.out.println("TID: " + bookinghistory.getTID());
			System.out.println("Name: " + bookinghistory.getMoviegoer().getName());
			System.out.println("Mobile: " + bookinghistory.getMoviegoer().getMobile());
			System.out.println("Email: " + bookinghistory.getMoviegoer().getEmail());
			System.out.println("Movie: " + bookinghistory.getShowtime().getMovie().getTitle());
			System.out.println("Cinema: " + bookinghistory.getShowtime().getCinema().getCode());
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd hh:mm");  
		    String strDate= formatter.format(bookinghistory.getShowtime().getTime());
			System.out.println("Time: " + strDate);
			int row = (bookinghistory.getSeat()-10000)/100;
        	int column = bookinghistory.getSeat()%100;
			System.out.println("Seat: row " + row + ", column " + column);
			System.out.println();
		}
		
		System.out.println("Press ENTER to go back.");
		getString();
		destroy();
	}
}
