package Boundary;

import static Control.DataManager.*;
import static Control.FileManager.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import Entity.Movie;
import Entity.Showtime;

/**
 * 
 * Allows users to select movie showtimes
 *
 */
public class ShowtimeView extends View{
	
	private Movie movie;
	
	public ShowtimeView(Movie movie) {
		this.movie = movie;
	}
	
	public void start() {
		System.out.println("Showtimes:\n");
		if (movie.getStatus().equals("COMING SOON") || movie.getStatus().equals("END OF SHOWING")) {
			System.out.println("Movie is not showing currently. No showtimes.");
			System.out.println("Press ENTER to go back.");
			getString();
			destroy();
		}
		else {
			ArrayList<Showtime> showtimes = getShowtimes(movie);
			for (int i=0;i<showtimes.size();i++) {
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm");  
			    String strDate= formatter.format(showtimes.get(i).getTime());
				System.out.println((i+1)+". " + showtimes.get(i).getCinema().getCode() + ":" + strDate);
			}
			System.out.println((showtimes.size()+1) + ". Go back");
			
			int choice = getChoice(1, showtimes.size()+1);
			
			if (choice == showtimes.size()+1) destroy();
			else selectShowtime(showtimes.get(choice-1));
		}
	}
	/**
	 * Selects the showtime and uses it to book seats
	 * @param showtime selected by the user and used in booking
	 */
	private void selectShowtime(Showtime showtime) {
		System.out.println("1. Check seat availability.");
		System.out.println("2. Book seat.");
		System.out.println("3. Check price.");
		System.out.println("4. Go back.");
		
		int choice = getChoice(1,4);
		switch (choice) {
		case 1:
			printSeats(showtime);
			System.out.println("Press ENTER to go back.");
			getString();
			destroy();
			break;
		case 2:
			transit(this, new BookingView(showtime));
			break;
		case 3:
			printPricing(showtime, true, true);
			System.out.println("Press ENTER to go back.");
			getString();
			destroy();
			break;
		case 4:
			destroy();
		}
	}
	
}
