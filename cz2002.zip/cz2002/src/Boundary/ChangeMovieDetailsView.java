package Boundary;


/**
 * UI for staff to change movie details
 */
import static Control.DataManager.*;
import static Control.FileManager.*;

import java.util.ArrayList;

import Entity.Movie;

public class ChangeMovieDetailsView extends View{
	private Movie movie;
	
	public ChangeMovieDetailsView(Movie movie) {
		this.movie = movie;
	}
	
	public void start() {
		System.out.println("\nChange movie details:\n");
		System.out.println("1. Age restriction.");
		System.out.println("2. Director.");
		System.out.println("3. Synopsis.");
		System.out.println("4. Cast.");
		System.out.println("5. Status.");
		System.out.println("6. Go back.");
		
		switch (getChoice(1,6)) {
		case 1:
			System.out.println("New age restriction:(1. G, 2. PG, 3. PG13, 4. M18, 5. R21):");
				String ageRestriction;
				switch (getChoice(1,5)) {
				case 1:
					ageRestriction = "G";
					break;
				case 2:
					ageRestriction = "PG";
					break;
				case 3:
					ageRestriction = "PG13";
					break;
				case 4:
					ageRestriction = "M18";
					break;
				default:
					ageRestriction = "R21";
				}
				movie.setAgeRestriction(ageRestriction);
				updateMovies(movie);
			destroy();
				break;
		case 2:
			System.out.print("New director:");
			String director = getString();
			movie.setDirector(director);
			updateMovies(movie);
			destroy();
			break;
		case 3:
			System.out.print("Synopsis:");
			String synopsis = getString();
			movie.setSynopsis(synopsis);
			updateMovies(movie);
			destroy();
			break;
		case 4:
			System.out.print("Cast (Separate cast members with ':', eg. \"john:mary\" :");
			String caststr = getString();
			ArrayList<String> cast = new ArrayList<String>();
			for (String i: caststr.split(":")) cast.add(i);
			movie.setCast(cast);
			updateMovies(movie);
			destroy();
			break;
		case 5:
			System.out.print("Choose movie showing status (1. COMING SOON, 2. NOW SHOWING, 3. END OF SHOWING) :");
			String status;
			switch (getChoice(1,3)) {
			case 1:
				status = "COMING SOON";
				break;
			case 2:
				status = "NOW SHOWING";
				break;
			default:
				status = "END OF SHOWING";
			}
			movie.setStatus(status);
			updateMovies(movie);
			destroy();
			break;
		default:
			destroy();
		}
	}
}
