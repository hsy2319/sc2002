package Boundary;

import static Control.DataManager.*;
import static Control.FileManager.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import Entity.Movie;
import Entity.Showtime;
import Entity.Cinema;
/**
 * 
 * Used by staff to create new showtimes
 *
 */
public class StaffShowtimeView extends View{
	private Movie movie;
	
	/**
	 * movie object used by staff to create showtimes
	 * @param movie
	 */
	public StaffShowtimeView(Movie movie) {
		this.movie = movie;
	}

	public void start() {
		System.out.println("Showtimes:\n");
		if (movie.getStatus().equals("COMING SOON") || movie.getStatus().equals("END OF SHOWING")) {
			System.out.println("Movie is not showing now. No showtimes.");
			System.out.println("Press ENTER to go back.");
			getString();
			destroy();
		}
		else {
			ArrayList<Showtime> showtimes = getShowtimes(movie);
			for (int i=0;i<showtimes.size();i++) {
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm");  
			    String strDate= formatter.format(showtimes.get(i).getTime());
				System.out.println((i+1)+". " + showtimes.get(i).getCinema().getCode() + ":" + strDate);
			}
			System.out.println((showtimes.size()+1) + ". Add showtime.");
			System.out.println((showtimes.size()+2) + ". Go back.");
			
			int choice = getChoice(1, showtimes.size()+2);
			if (choice == showtimes.size()+2) {
				destroy();
			}
			else if (choice == showtimes.size()+1) {
				System.out.println("Choose cinema:");
				ArrayList<Cinema> cinemas = getCinemas();
				for (int i=0; i<cinemas.size();i++) {
					System.out.println((i+1)+". Cineplex:"+cinemas.get(i).getCineplex()+" Cinema code: "+cinemas.get(i).getCode());
					
				}
				Cinema thiscinema = cinemas.get(getChoice(1,cinemas.size())-1);
				System.out.println("Please enter the showtime's date in dd-MM-yyyy hh:mm form (eg. 21-04-2023 12:00): ");
				Date time = getDate();
				int Seat[][] = new int[8][16];
				for (int i=0;i<8;i++) {
					for (int j=0;j<16;j++) {
						Seat[i][j] = 0;
					}
				}
				
				addShowTime(new Showtime(movie, thiscinema, time, Seat));
				System.out.println("\nShowtime added");
				System.out.println("Press ENTER to go back.");
				getString();
				destroy();
			}
			else{
				removeShowtime(showtimes.get(choice-1));
				System.out.println("\nShowtime deleted");
				System.out.println("Press ENTER to go back.");
				getString();
				destroy();
			}
		}
	}
}
