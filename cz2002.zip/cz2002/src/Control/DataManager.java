package Control;

import static Control.DataManager.getInt;
import static Control.DataManager.isWeekend;
import static Control.FileManager.is3dPremium;
import static Control.FileManager.isPlatinumPremium;
import static Control.FileManager.weekendPremium;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import Entity.Showtime;
/***
 * 
 * Reads and formats wide variety of user data
 *
 */
public class DataManager {
	/**
	 * Gets a int variable between a and b from the user
	 * @param a the lower limit
	 * @param b the upper limit
	 * @return
	 */
	public static int getChoice(int a, int b) {
		try {
			Scanner sc = new Scanner(System.in);
			int choice = sc.nextInt();
			if (choice>=a && choice<=b) return choice;
			else {
				System.out.println("Invalid choice. Please choose again.\n");
				return getChoice(a,b);
			}
		} catch (InputMismatchException e) {
			System.out.println("Invalid choice. Please choose again.\n");
			return getChoice(a,b);
		}
	}
	/**
	 * Gets a String variable from user input
	 * @return
	 */
	public static String getString() {
			Scanner sc = new Scanner(System.in);
			String choice = sc.nextLine();
			return choice;
	}
	
	/**
	 * gets a boolean input from user
	 * @return
	 */
	public static boolean getYesNo() {
		Scanner sc = new Scanner(System.in);
		String choice = sc.nextLine();
		if (choice.toUpperCase().charAt(0)=='Y') return true;
		if (choice.toUpperCase().charAt(0)=='N') return false;
		else {
			System.out.println("Invalid choice. Please choose again.\n");
			return getYesNo();
		}
	}
	/**
	 * gets an int input from user
	 * @return
	 */
	public static int getInt() {
		try {
			Scanner sc = new Scanner(System.in);
			int choice = sc.nextInt();
			return choice;
		} catch (InputMismatchException e) {
			System.out.println("Invalid entry. Please enter an integer.\n");
			return getInt();
		}
	}
	/**
	 * gets a double input from user
	 * @return
	 */
	public static double getDouble() {
		try {
			Scanner sc = new Scanner(System.in);
			double choice = sc.nextDouble();
			return choice;
		} catch (InputMismatchException e) {
			System.out.println("Invalid entry. Please enter a double value.\n");
			return getDouble();
		}
	}
	
	/**
	 * gets seat from showtime to check if assigned correctly
	 * @param showtime showtime containing the seats
	 * @return an int representation of the seat matrix
	 */
	public static int checkSeat(Showtime showtime) {
		try {
			System.out.print("Enter row: ");
			int row = getInt();
			System.out.print("Enter column: ");
			int column = getInt();
			if (showtime.getSeats()[row-1][column-1]==0) return 10000+100*(row)+column;
			else {
				System.out.println("Seat already taken. Please choose again.\n");
				return checkSeat(showtime);
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Invalid entry. Please choose again.\n");
			return checkSeat(showtime);
		}
	}
	
	/**
	 * checks if date is a weekend
	 * @param date
	 * @return true if date is weekend, false if not
	 */
	public static boolean isWeekend(Date date) {
		Calendar c1 = Calendar.getInstance();
	    c1.setTime(date);
	    if ((c1.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) 
	            || (Calendar.DAY_OF_WEEK == Calendar.SUNDAY)) return true;
	    return false;
	}
	
	/**
	 * prints the seats matrix from the showtime
	 * @param showtime showtime containing the seat matrix
	 */
	public static void printSeats(Showtime showtime) {
		System.out.println("Seat availability:\n");
		System.out.println("------------SCREEN------------");
		System.out.println("  1   2   3   4   5   6   7   8       9   10  11  12  13  14  15  16");
		for (int i=0; i<8;i++) {
			System.out.print(i+1);
			for (int j=0;j<16;j++) {
				if (j!=7 && showtime.getSeats()[i][j]==1) System.out.print("[x] ");
				else if (j!=7 && showtime.getSeats()[i][j]==0) System.out.print("[ ] ");
				else if (j==7 && showtime.getSeats()[i][j]==1) System.out.print("[x]     ");
				else if (j==7 && showtime.getSeats()[i][j]==0) System.out.print("[ ]     ");
			}
			System.out.print("\n");
		}
	}
	
	/**
	 * Prints different prices for regular and senior customers depending on information in showtime
	 * @param showtime showtime containing information on pricing
	 * @param showReg if regular prices should be shown
	 * @param showSenior if senior citizen prices should be shown
	 * @return
	 */
	public static double printPricing(Showtime showtime, boolean showReg, boolean showSenior) {
		System.out.println("Ticket prices for "+showtime.getMovie().getTitle());
		double price = showtime.getCinema().getBasePrice();
		System.out.println("Cinema: "+showtime.getCinema().getCode());
		if (showtime.getCinema().getIs3d()) {
			System.out.print("(3d cinema) ");
			price*=is3dPremium;
		}
		if (showtime.getCinema().getIsPlatinum()) {
			System.out.print("(platinum cinema) ");
			price*=isPlatinumPremium;
		}
		if (isWeekend(showtime.getTime())) {
			System.out.println("(Weekend prices apply)");
			price*=weekendPremium;
		}
		System.out.println("Date: "+new SimpleDateFormat("dd/MM/yyyy hh:mm").format(showtime.getTime()));
		System.out.println();
		if (showReg) System.out.println("Regular Moviegoers: $"+(double) Math.round(100*price)/100);
		if (showSenior) System.out.println("Senior Citizens: $"+(double) Math.round(100*price/2)/100);
		if (showSenior) return (double) Math.round(100*price/2)/100;
		else return (double) Math.round(100*price)/100;
	}
	/**
	 * Gets a date input from user
	 * @return
	 */
	public static Date getDate() {
		Scanner sc = new Scanner(System.in);
		String choice = sc.nextLine();
		try {
			return new SimpleDateFormat("dd-MM-yyyy hh:mm").parse(choice);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			System.out.println("Invalid entry. Please try again.");
			return getDate();
		}
	}
}