package Entity;

/**
 * 
 * Entity class representing a moviegoer.
 *
 */
public class Moviegoer {
	
	private String name, mobile, email;
	private boolean isSeniorCitizen;
	
	public Moviegoer(String name, String mobile, String email, boolean isSeniorCitizen) {
        this.email = email;
        this.name = name;
        this.mobile = mobile;
        this.isSeniorCitizen = isSeniorCitizen;
    }
	
	public String getName() {
		return name;
	}
	
	public String getMobile() {
		return mobile;
	}
	
	public String getEmail() {
		return email;
	}
	
	public boolean getIsSeniorCitizen() {
		return isSeniorCitizen;
	}
}
