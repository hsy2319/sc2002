package Entity;

/**
 * 
 * Entity class representing a cinema
 *
 */
public class Cinema {
	private String cineplex;
    private boolean isPlatinum;
    private boolean is3d;
    private String code;
    private double basePrice;

    public Cinema(String cineplex, boolean isPlatinum, boolean is3d, String code, double basePrice) {
        this.cineplex = cineplex;
        this.isPlatinum = isPlatinum;
        this.is3d = is3d;
        this.code = code;
        this.basePrice = basePrice;
    }

    public String getCineplex() {
    	return cineplex;
    }
    
    public boolean getIsPlatinum() {
    	return isPlatinum;
    }
    
    public boolean getIs3d() {
    	return is3d;
    }
    
    public String getCode() {
    	return code;
    }
    
    public double getBasePrice() {
    	return basePrice;
    }
    
    public void setBasePrice(double basePrice) {
    	this.basePrice = basePrice;
    }
}
