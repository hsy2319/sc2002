package Entity;

import java.util.Date;

public class Review {
	
	private Date date;
	private String content;
	private int rating;
    private Movie movie;
    private String name;

    public Review(Movie movie, int rating, String content, String name) {
        if (rating >= 5) {
        	this.rating = 5;
        }
        else if (rating <= 1) {
        	this.rating = 1;
        }
        else this.rating = rating;
        this.date = new Date();
        this.content = content;
        this.movie = movie;
        this.name = name;
    }

    public Movie getMovie() {
        return movie;
    }

    public String getContent() {
        return content;
    }

    public int getRating() {
        return rating;
    }

    public String getName() {
    	return name; 
    }

    public Date  getDate() {
    	return date;
    }
}
